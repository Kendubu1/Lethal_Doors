# Lethal Doors
Transforms the hangar doors into a hazardous obstacle or helpful tool when your team is low on scrap on the last day! 

## How it Works
- Lethal Hangar Doors: Shortly after the ship lands, the hangar doors become deadly. If players are within a dangerous threshold of the door while closing they are either severely injury or terminated.
- Affected Player Tracking: Tracks the players affected in each door cycle to ensure damage is applied correctly and fairly.
- Requirements: Both Host & Clients Require Installing the Mod.

## Versions & Notes
Leave any comments for improvements or bugs on the github repo!
1.0.0.0 - Initial Release - Seeking helping getting this to work fully server side if possible. New to unity over here :)